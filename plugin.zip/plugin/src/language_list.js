let languages = [
    { "id": "en" }, // English
    { "id": "vi" }, // Vietnamese
    { "id": "es" }, // Spanish
    { "id": "fr" }, // French
    { "id": "de" }, // German
    { "id": "ja" }, // Japanese
    { "id": "zh" }, // Chinese
    { "id": "ko" }, // Korean
    { "id": "ru" }, // Russian
    { "id": "ar" }, // Arabic
    { "id": "pt" }, // Portuguese
    { "id": "hi" }, // Hindi
    // ... Thêm ngôn ngữ khác nếu API hỗ trợ
];
